import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from './model/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  url:string="http://localhost:3000/products"
  constructor(private http:HttpClient) { }

  getProducts(){
    return this.http.get<Product[]>(this.url);
  }

  addProduct(p:Product){
    return this.http.post(this.url,p);
  }

  getById(id:number){
    return this.http.get<Product>(this.url+"/"+id)
  }

  deleteproduct(p:Product){
    return this.http.delete<Product[]>(this.url+"/"+p.id);
  }
 
  updateproduct(p:Product){
    return this.http.put(this.url+"/"+p.id,p);
  }

}
