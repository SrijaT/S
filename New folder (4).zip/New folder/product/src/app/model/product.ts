export class Product {
    id:number;
    name:string;
    desg:string;
}
