import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ProductService } from '../product.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-updatepro',
  templateUrl: './updatepro.component.html',
  styleUrls: ['./updatepro.component.css']
})
export class UpdateproComponent implements OnInit {
  uproData:Product={"id":0,"name":'',"desg":''}
  uproForm:FormGroup;
  submitted:boolean=false;
  constructor(private service:ProductService,private router:Router,private aroute:ActivatedRoute,private formbuilder:FormBuilder) { }

  ngOnInit() {
    this.aroute.params.subscribe(
      (params)=>{
        this.service.getById(params['id']).subscribe(
          (result)=>{this.uproData=result}
        );
      }
    );
  }
  onSubmit(){
    this.service.updateproduct(this.uproData).subscribe(
      (data)=>{this.router.navigate([''])});
   }
}
