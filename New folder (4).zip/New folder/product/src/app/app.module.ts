import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http'
import { RouterModule, Routes } from '@angular/router'
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { UpdateproComponent } from './updatepro/updatepro.component';

const routes:Routes=[
  {path:'',component:HomeComponent},
  {path: 'add',component:AddproductComponent},
  {path: 'update/:id',component:UpdateproComponent},
];
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AddproductComponent,
    UpdateproComponent
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule,RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
