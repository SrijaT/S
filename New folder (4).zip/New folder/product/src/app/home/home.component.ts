import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../model/product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
products:Product[];

  constructor(private service:ProductService) { }


  ngOnInit() {
    this.service.getProducts().subscribe((data:Product[])=>{this.products=data});
    console.log(this.products);
  } 
  
  deleteProduct(c:Product){
    this.service.deleteproduct(c).subscribe(
      (result)=>{this.products=this.products.filter(cc=>cc!==c)}
    )
  }

}
