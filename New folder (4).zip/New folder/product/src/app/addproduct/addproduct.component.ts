import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
  proData:Product={"id":0,"name":'',"desg":''}
  constructor(private service:ProductService,private router:Router) { }

  ngOnInit() {
  }

  onSubmit(){
    console.log(this.proData.id);
    this.service.addProduct(this.proData).subscribe((data)=>{
        this.router.navigate(['']);
      });
  }

}
