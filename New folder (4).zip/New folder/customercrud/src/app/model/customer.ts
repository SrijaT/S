export class Customer {
    id:number;
    name:string;
    eamil:string;
    phone:number;
    
}
