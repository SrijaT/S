import { Component, OnInit } from '@angular/core';
import { Validators } from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CustomerService } from '../service/customer.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Customer } from '../model/customer';
@Component({
  selector: 'app-mycust',
  templateUrl: './mycust.component.html',
  styleUrls: ['./mycust.component.css']
})
export class MycustComponent implements OnInit {
  custData:Customer={"id":0,"name":'',"eamil":'',"phone":0}
  custForm:FormGroup;
  submitted:boolean=false;
  constructor(private service:CustomerService,private router:Router,private aroute:ActivatedRoute,private formbuilder:FormBuilder) { }
  ngOnInit(){
  this.custForm=this.formbuilder.group({
      id:['',Validators.required,'',Validators.pattern('[0-9]{2,5}')],
      name:['',Validators.required,'',Validators.pattern('[a-zA-Z]{5,30}')],
      email:['',Validators.required,'',Validators.email],
      phone:['',Validators.required,'',Validators.pattern('[0-9]{10}')],
    });
  }

  onSubmit(){
      this.submitted=true;this.custData=this.custForm.value;
      alert(this.custData.id+" "+this.custData.name);
      this.service.addCustomer(this.custData).subscribe((data)=>{
        this.router.navigate(['listcustomer']);
      });
      if(this.custForm.invalid) return;
   }

}
