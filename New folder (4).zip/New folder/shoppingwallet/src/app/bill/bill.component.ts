import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

import { Product } from '../model/product';
import { CustService } from '../service/cust.service';

@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {
  amount:number;
  product:Product;

  constructor(private service:CustService,private router:Router,private aroute:ActivatedRoute){}

  ngOnInit(){
    
    this.amount=this.service.getAmount();
    this.aroute.params.subscribe(
      (params)=>{
        this.service.getById(params['id']).subscribe(
          (result)=>{this.product=result}
        );
        console.log(this.product);
      }
    );
  }
}
