export class Customer {
    name:string;
    phone:number;
    amount:number;
}
