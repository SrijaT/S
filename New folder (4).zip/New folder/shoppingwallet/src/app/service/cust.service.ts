import { Injectable } from '@angular/core';
import { Customer } from '../model/customer';
import { HttpClient } from '@angular/common/http';
import { Product } from '../model/product';

@Injectable({
  providedIn: 'root'
})
export class CustService {
  url:string="http://localhost:3000/customers"
  url1:string="http://localhost:3000/products"
  amount:any;
  name:string;
  constructor(private http:HttpClient) { }

  addCustomer(customer:Customer){
    return this.http.post(this.url,customer);
  }
  getproducts(){
    return this.http.get<Product[]>(this.url1);
  }

  getById(id:number){
    console.log("get"+id);
    return this.http.get<Product>(this.url1+"/"+id)
  }

  setAmount(amount){
this.amount=amount;
  }
  setName(name){
    this.name=name;
      }
      getAmount(){
        return this.amount;
      }
      getName(){
        return this.name;
      }
}
