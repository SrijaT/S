import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http'
import { RouterModule, Routes } from '@angular/router'
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { BuyComponent } from './buy/buy.component';
import { CustService } from './service/cust.service';
import { BillComponent } from './bill/bill.component';

const routes:Routes=[
  {path:'',component:HomeComponent},
  {path:'buy',component:BuyComponent},
  {path:'bill/:id',component:BillComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BuyComponent,
    BillComponent
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule,RouterModule.forRoot(routes)
  ],
  providers: [CustService],
  bootstrap: [AppComponent]
})
export class AppModule { }
